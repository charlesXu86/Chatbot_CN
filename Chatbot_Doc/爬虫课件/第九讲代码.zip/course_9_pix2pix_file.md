https://github.com/wiibrew/pix2pix-tensorflow-1
